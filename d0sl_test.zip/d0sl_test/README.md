# d0SL SDK beta
Delta Zero Semantic Language (d0SL) is based on the theory of semantic modeling, which allows you to set the behavior of complex systems and business processes in the terms of logic.

Here are you can find the examples of usage Delta Zero Semantic language.

1) Autodrome example shows how to control robocars by defining logical rules
2) Chess example shows how to teach a robot to arrange the 8 chess queens in such a way they dont take each other.

See documentation (installation & guides) on [d0sl.org](http://d0sl.org).

This project is created with MPS 2021.3 version, build 213.6777.846 from 15.02.2022
